a= int(input("value:"))
if a % 4 == 0 :
    print("leapyear not")
else:
    print("leapyear")   