a=int(input("Input a:"))
b=int(input("Input b:"))
b=int(input("input c:"))
if a>b and a>c:
    print("Greater is A")
elif b>c and b>a:
    print("Greater is B")
else:
    print("Greater is C")