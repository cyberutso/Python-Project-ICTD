#1+2+3+4+5+............+n=koto?
sum=0
a=int(input('Enter the value n:'))
for i in range(1,a+1,1):
    sum=sum+i
print(sum)




   



