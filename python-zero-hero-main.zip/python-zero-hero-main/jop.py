a =int(input("value:"))
b=int(input("value:"))
if a>0:
    print("possitive")
elif a==0:
    print("zero")
else:
    print("negative")   
