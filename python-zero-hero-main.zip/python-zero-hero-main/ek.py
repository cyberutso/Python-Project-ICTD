sum=0
for x in range(1,101,1):
    sum=sum+x
print (sum)
