add =( 'potato','rice','vom')
add.append('zoom')
print(add) 