r=1
sum=0
while r <= 100:
    sum=sum+r
    a= r+1
print(sum)