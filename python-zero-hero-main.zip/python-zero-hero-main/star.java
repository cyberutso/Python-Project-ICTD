public class Main {
    public static void main(string[] args) {

       System.out.println("*");
       System.out.println("**");
       System.out.println("***");
       System.out.println("****");
    }
}