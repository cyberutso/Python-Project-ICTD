a=int(input())
b=int(input())
c=int(input())
if a>b and a>c:
    print("the maximum value is",a)
 elif b>a and b<c:
    print("the minimum value is",b)
else:
    print("the maximum value is",c)    
