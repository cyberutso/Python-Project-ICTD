a=int(input("value:"))
b=int(input("value:"))
c=int(input("value:"))
sub=a-b
biyog=a+b
if sub == biyog:
    print("value of biyog is:")
else:
    print(f"value of jog is:(jog)")    


