x=2
sum=0
while x <= 100:
    sum =sum + x
    x=x+2
print(sum)