for i in range(100):
    a=int(input("BIKASH\n1:Send soney\n2:send money to non bikash user\n3:Mobile Recharge\n4:Payment\n5:cash out\n6:pay bill\n7:reset")s)
    if a==1:
print("Enter your phone number:")
