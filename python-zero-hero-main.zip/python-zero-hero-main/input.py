a=int(input("Enter the value:"))
total=0
for i in range(0,len(a)):
    total=total+int(a[""])
print(total)








