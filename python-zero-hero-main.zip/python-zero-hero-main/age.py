a=int(input("Enter the value of age:"))
if a>=1 and a<=10:
    print("You are child")
elif a>=11 and a<=18:
    print("Mid age")
elif a>=19 and a<=25:
    print("You are hero")
elif a>=26 and a<=100:
    print('You are old')
else:
    print("invalid")
