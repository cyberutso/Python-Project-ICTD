sum = 0
for a in range (0,101,2):
    sum = sum+a
print(sum)