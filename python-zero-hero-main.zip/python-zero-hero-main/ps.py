a=5
b=2
if a>b:
    print("5 is getter than 2")