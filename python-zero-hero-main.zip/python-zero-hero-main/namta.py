num=int(input("Enter the value of namta:"))

for i in range(1,11,1):
    namta=i*num
    print(num,"x",i,"=",namta)