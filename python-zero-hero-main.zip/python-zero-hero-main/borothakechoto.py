a =int(input())
b =int(input())
if a>b;
print("maximum value is,"a)
else:
    print("maximun value is,"b)
