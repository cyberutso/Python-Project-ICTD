a=int(input("enter MATH_3 mark:"))
b=int(input("Enter Chemistry mark:"))
c=int(input("Enter Social_science mark:"))
d=int(input("Enter P.A mark:"))
#math_cadit=4
#Chemistry_cadit=4
#social_science_cadit=4
#pa_cadit=3
v=(a*4)/4
x=(b*4)/4
y=(c*4)/4
z=(d*3)/3
if v>=80 and v<=100:
    print("you got GPA 4.00(A+) ")
elif v>=75 and v<=79:
    print("you got GPA 3.75(A) ")
elif v>=70 and v<=74:
    print("you got GPA 3.50(A-) ")
elif v>=65 and v<=69:
    print("you got GPA 3.00(B+) ")
elif v>=60 and v<=64:
    print("you got GPA 2.75(B) ")
elif v>=50 and v<=54:
    print("you got GPA 2.50(c+) ")
elif v>=45 and v<=49:
    print("you got GPA 2.25(C) ")
elif v>=40 and v<=48:
    print("you got GPA 2.00(C-) ")
elif v>=0 and v<=33:
    print("you got GPA 0.00(F) ")

#chemistry
elif x>=80 and x<=100:
    print("you got GPA 4.00(A+) ")
if x>=80 and x<=100:
    print("you got GPA 4.00(A+) ")
elif x>=75 and x<=79:
    print("you got GPA 3.75(A) ")
elif x>=70 and x<=74:
    print("you got GPA 3.50(A-) ")
elif x>=65 and x<=69:
    print("you got GPA 3.00(B+) ")
elif x>=60 and x<=64:
    print("you got GPA 2.75(B) ")
elif x>=50 and x<=54:
    print("you got GPA 2.50(c+) ")
elif x>=45 and x<=49:
    print("you got GPA 2.25(C) ")
elif x>=40 and x<=48:
    print("you got GPA 2.00(C-) ")
elif x>=0 and x<=33:
    print("you got GPA 0.00(F) ")



#social_science
elif y>=80 and y<=100:
    print("you got GPA 4.00(A+) ")
if y>=80 and y<=100:
    print("you got GPA 4.00(A+) ")
elif y>=75 and y<=79:
    print("you got GPA 3.75(A) ")
elif y>=70 and y<=74:
    print("you got GPA 3.50(A-) ")
elif y>=65 and y<=69:
    print("you got GPA 3.00(B+) ")
elif y>=60 and y<=64:
    print("you got GPA 2.75(B) ")
elif y>=50 and y<=54:
    print("you got GPA 2.50(c+) ")
elif y>=45 and y<=49:
    print("you got GPA 2.25(C) ")
elif y>=40 and y<=48:
    print("you got GPA 2.00(C-) ")
elif y>=0 and y<=33:
    print("you got GPA 0.00(F) ")

    
#chemistry
elif z>=80 and z<=100:
    print("you got GPA 4.00(A+) ")
if z>=80 and z<=100:
    print("you got GPA 4.00(A+) ")
elif z>=75 and z<=79:
    print("you got GPA 3.75(A) ")
elif z>=70 and z<=74:
    print("you got GPA 3.50(A-) ")
elif z>=65 and z<=69:
    print("you got GPA 3.00(B+) ")
elif z>=60 and z<=64:
    print("you got GPA 2.75(B) ")
elif z>=50 and z<=54:
    print("you got GPA 2.50(c+) ")
elif z>=45 and z<=49:
    print("you got GPA 2.25(C) ")
elif z>=40 and z<=48:
    print("you got GPA 2.00(C-) ")
elif z>=0 and z<=33:
    print("you got GPA 0.00(F) ")
else:
    print("invalid Marks")