sum=0
for x in range(1,101,2):
    sum=sum+x
print(sum)
