f =int(input("Enter the value of this:"))
c =(f-32)*5/9
print("cescious scale tep.=",c)