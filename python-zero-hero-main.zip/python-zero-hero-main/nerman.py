n=int(input("Enter the value of N:"))
for a in range(1,n,1):
    print("HARE KRISHNA")
