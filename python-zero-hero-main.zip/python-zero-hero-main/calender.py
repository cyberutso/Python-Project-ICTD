import calendar
year=2022
month=11
x=calendar.month(year,month)
print(x)