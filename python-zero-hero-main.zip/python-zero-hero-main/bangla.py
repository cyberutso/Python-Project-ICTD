list= ["apple","kola","lichu","am","jam"]
if "kola" in  list :
    print("YEs! this is on the way")
   
