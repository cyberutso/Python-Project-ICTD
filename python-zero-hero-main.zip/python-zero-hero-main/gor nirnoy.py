n=int(input("how to integer number"))
sum=0
i=0
while i<n:
a=input()
sum=sum+a
i=i+1
avg=sum/n
print("summation of numbers=",sum)
print("average of numbers=",avg)
