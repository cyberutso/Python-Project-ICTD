a=1
sum=0
while a<=100:
    sum=sum + a
    a=a+2
print(sum)