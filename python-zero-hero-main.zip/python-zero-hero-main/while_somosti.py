a=int(input("Enter your N:"))
x=0
sum=0
while x<=a:
    sum=x+1
    x=x+1
print( sum)