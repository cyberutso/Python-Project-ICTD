def show():
 print("BANGLADESH EDUCATION BOARD ")
    
show()
